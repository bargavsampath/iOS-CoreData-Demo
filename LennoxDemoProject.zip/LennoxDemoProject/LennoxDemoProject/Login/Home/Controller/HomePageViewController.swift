//
//  HomePageViewController.swift
//  TaskApp
//
//  Created by apple on 01/10/20.
//  Copyright © 2020 apple. All rights reserved.
//

import UIKit
import CoreData
import Cosmos

class HomePageViewController: UIViewController {
    let storyBoard = UIStoryboard(name: "Main", bundle: nil)
     var window: UIWindow?
    
    var activityView = UIActivityIndicatorView(style: .large)
    
    @IBOutlet weak var amountLabel: UILabel!
    @IBOutlet weak var homeTable: UITableView!
    @IBOutlet weak var hideView: UIView!
    @IBOutlet weak var amountTextField: UITextField!
    @IBOutlet weak var ratingView: CosmosView!
    @IBOutlet weak var ratingLbl: UILabel!
    
    var userData: [NSManagedObject] = []
    var amountString = ""
    
    @IBAction func logOutButton(_ sender: UIBarButtonItem) {

      
       
       // Switcher.updateRootVC()
     
        
       // self.window = UIWindow(windowScene: windowScene)
        
        UserDefaults.standard.set(false, forKey: "isLoggedIn")
        let loginVC = (self.storyBoard.instantiateViewController(withIdentifier: "LoginViewController") as? LoginViewController)!
       self.navigationController?.pushViewController(loginVC, animated: true)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.navigationBar.isHidden = true
        activityView.center = self.view.center
        self.view.addSubview(activityView)
        ratingView.didTouchCosmos = {rating in
            print("Ratings:-\(self.ratingView.rating)")
            self.ratingLbl.text = "\(self.ratingView.rating)"
        }
        
        
    }
    
    @IBAction func HideBtnTap(_ sender: Any) {
//        self.homeTable.isHidden = true
//        self.hideView.isHidden = true
    }
    
    
    
    @IBAction func logoutBtnTap(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
        UserDefaults.standard.set(false, forKey: "isLoggedIn")
        
    }
    
   
    
    @IBAction func submitBtnTap(_ sender: Any) {
        
    }
    
   
    
    override func viewWillAppear(_ animated: Bool) {
        
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        navigationController?.setNavigationBarHidden(false, animated: animated)
    }
    
    
}




