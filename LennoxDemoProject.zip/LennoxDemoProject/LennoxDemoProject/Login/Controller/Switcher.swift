//
//  Switcher.swift
//  LennoxDemoProject
//
//  Created by vijay g on 22/12/20.
//  Copyright © 2020 developer. All rights reserved.
//

import Foundation
import UIKit

class Switcher {
    
    static func updateRootVC(){
        
        let status = UserDefaults.standard.bool(forKey: "isLoggedIn")
        var rootVC : UIViewController?
       
            print(status)
        

        if(status == true){
            rootVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "HomePageViewController") as! HomePageViewController
        }else{
            rootVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "LoginViewController") as! LoginViewController
        }
        
//        let appDelegate =UIWindowScene. AppDelegate
//        appDelegate.window?.rootViewController = rootVC
        
    }
    
}
