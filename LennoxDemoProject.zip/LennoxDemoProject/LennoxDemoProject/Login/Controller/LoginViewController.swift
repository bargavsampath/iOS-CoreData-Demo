//
//  LoginViewController.swift
//  TaskApp
//
//  Created by apple on 01/10/20.
//  Copyright © 2020 apple. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {
    
    @IBOutlet weak var emailidTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var loginBtnRef: UIButton!
    @IBOutlet weak var signUpBtnRef: UIButton!
    
       let storyBoard = UIStoryboard(name: "Main", bundle: nil)
       
       override func viewDidLoad() {
           super.viewDidLoad()
        
        // Do any additional setup after loading the view.
       }
    
    func validate(emailAddress: String) -> Bool {
        let REGEX: String
        REGEX = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,6}"
        return NSPredicate(format: "SELF MATCHES %@", REGEX).evaluate(with: emailAddress)
    }
       
       
       @IBAction func loginBtnTap(_ sender: Any) {
        
        guard let emailStr = emailidTextField.text, !emailStr.isEmpty else {
                      /// Please enter mob no.
                      let alertController = UIAlertController(title: "Login", message: "Please Enter Email Id", preferredStyle: .alert)
                      alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                      self.present(alertController, animated: true, completion: nil)
                      return
                  }
        
        //Enter Valid Email id
        guard let emailText = emailidTextField.text, self.validate(emailAddress: emailText) else {
            
            let alertController = UIAlertController(title: "Login", message: "Please Enter Valid Email id", preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alertController, animated: true, completion: nil)
            return
        }
        
           guard let passwordStr = passwordTextField.text, !passwordStr.isEmpty else {
               /// Please enter mob no.
               let alertController = UIAlertController(title: "SignUp", message: "Please Enter Password", preferredStyle: .alert)
               alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
               self.present(alertController, animated: true, completion: nil)
               return
           }
           
//        let results = PersistenceManager.sharedInstance.fetchUser("Users", emailId: emailStr, password: passwordStr)
//           if results.count > 0 {
//
//               let alertController = UIAlertController(title: "Login", message: "LoggedIn successfully", preferredStyle: .alert)
//               alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: { action in
//
//                   UserDefaults.standard.set(true, forKey: "isLoggedIn")
//
//                   /// Navigate to home screen
//                   let homeVC = self.storyBoard.instantiateViewController(withIdentifier: "HomePageViewController") as? HomePageViewController
//                   self.navigationController?.pushViewController(homeVC!, animated: true)
//               }))
//               self.present(alertController, animated: true, completion: nil)
//           }
        let fetchRecult = PersistenceManager.sharedInstance.fetchUser("Users", emailId: emailStr, password: passwordStr)
        if fetchRecult.count>0
        {
            let objectEntity : Users = fetchRecult.first as! Users
            if objectEntity.email == emailStr && objectEntity.password == passwordStr
            {
                let alertController = UIAlertController(title: "Login", message: "LoggedIn successfully", preferredStyle: .alert)
                alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: { action in
                    
                    UserDefaults.standard.set(true, forKey: "isLoggedIn")
                    
                    /// Navigate to home screen
                    let homeVC = self.storyBoard.instantiateViewController(withIdentifier: "HomePageViewController") as? HomePageViewController
                    self.navigationController?.pushViewController(homeVC!, animated: true)
                }))
                self.present(alertController, animated: true, completion: nil)
                //return true   // Entered Username & password matched
            }
                
            else
            {
                let alertController = UIAlertController(title: "Login", message: "Please Enter Your Register Email id and Password", preferredStyle: .alert)
                alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: { action in
                    /// Navigate to home screen
                }))
                self.present(alertController, animated: true, completion: nil)
                //return false  //Wrong password/username
            }
        }
            
        else{
            let alertController = UIAlertController(title: "Login", message: "Please Enter Your Register Email id and Password", preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: { action in
                /// Navigate to home screen
            }))
            self.present(alertController, animated: true, completion: nil)
            
        }
           
       
    }
       
       @IBAction func signupButtonTap(_ sender: Any) {
           let registerVC = storyBoard.instantiateViewController(withIdentifier: "SignupViewController") as? SignupViewController
           self.navigationController?.pushViewController(registerVC!, animated: true)
       }
    




}

//extension LoginViewController: UITextFieldDelegate {
//    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
//        let maxLength = 10
//        let currentString: NSString = (textField.text ?? "") as NSString
//        let newString: NSString =
//            currentString.replacingCharacters(in: range, with: string) as NSString
//        return newString.length <= maxLength
//    }
//}
