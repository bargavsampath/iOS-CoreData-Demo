//
//  SignupViewController.swift
//  TaskApp
//
//  Created by apple on 01/10/20.
//  Copyright © 2020 apple. All rights reserved.
//

import UIKit

class SignupViewController: UIViewController {
    
    
    @IBOutlet weak var signUpBtnRef: UIButton!
    let storyBoard = UIStoryboard(name: "Main", bundle: nil)
    
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var mobileNumberTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    //    MARK:- Email Validations
    
    func validate(emailAddress: String) -> Bool {
        let REGEX: String
        REGEX = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,6}"
        return NSPredicate(format: "SELF MATCHES %@", REGEX).evaluate(with: emailAddress)
    }
    
    @IBAction func signupButtonTap(_ sender: Any) {
        
        guard let nameStr = nameTextField.text, !nameStr.isEmpty else {
            /// Please enter name.
            let alertController = UIAlertController(title: "SignUp", message: "Please Enter Name", preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alertController, animated: true, completion: nil)
            return
        }
        guard let emailStr = emailTextField.text, !emailStr.isEmpty else {
            /// Please enter mob no.
            let alertController = UIAlertController(title: "SignUp", message: "Please Enter Email Id", preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alertController, animated: true, completion: nil)
            return
        }
        //Enter Valid Email id
        guard let emailText = emailTextField.text, self.validate(emailAddress: emailText) else {
            
            let alertController = UIAlertController(title: "SignUp", message: "Please Enter Valid Email id", preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alertController, animated: true, completion: nil)
            return
        }
        
        guard let mobNumberStr = mobileNumberTextField.text, !mobNumberStr.isEmpty else {
            /// Please enter mob no.
            let alertController = UIAlertController(title: "SignUp", message: "Please Enter Mobile Number", preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alertController, animated: true, completion: nil)
            return
        }
        
        guard let passwordStr = passwordTextField.text, !passwordStr.isEmpty else {
            /// Please enter name.
            let alertController = UIAlertController(title: "SignUp", message: "Please Enter password", preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alertController, animated: true, completion: nil)
            return
        }
        
        
        //MARK: CORE DATA CRUD
        let results = PersistenceManager.sharedInstance.fetchUser("Users", emailId: emailStr, password: passwordStr)
        if results.count > 0 {
            //Mob number already registered
            let alertController = UIAlertController(title: "SignUp", message: "This mobile is already registered!", preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alertController, animated: true, completion: nil)
            return
        }
        else {
            /// Save details to coredata
            let usersDict = ["namestr":nameStr,"emailStr":emailStr,"mobileNum": mobNumberStr,"passwordStr":passwordStr] as [String : Any]
            PersistenceManager.sharedInstance.addUser(usersDict: usersDict) { (status, error) in
                if status {
                    let alertController = UIAlertController(title: "SignUp", message: "Registered successfully", preferredStyle: .alert)
                    alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: { action in
                        
                        /// Navigate to home screen
                        //                        let homeVC = self.storyBoard.instantiateViewController(withIdentifier: "LoginViewController") as? LoginViewController
                        //                        self.navigationController?.pushViewController(homeVC!, animated: true)
                        self.navigationController?.popViewController(animated: true)
                    }))
                    self.present(alertController, animated: true, completion: nil)
                }
            }
        }
        
    }
    
}

//extension SignupViewController: UITextFieldDelegate {
//    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
//        let maxLength = 10
//        let currentString: NSString = (textField.text ?? "") as NSString
//        let newString: NSString =
//            currentString.replacingCharacters(in: range, with: string) as NSString
//        return newString.length <= maxLength
//    }
//}
